fetch('index.html')
    .then(response => response.text())
    .then(data => {
        // Extract the header content from the fetched data
        // Extract the content of the 'header' div
        const parser = new DOMParser();
        const doc = parser.parseFromString(data, 'text/html');
        const headerContent = doc.getElementById('header1').innerHTML;
        const signUpModal = doc.getElementById('signup-modal').innerHTML;
        const signInModal = doc.getElementById('signin-modal').innerHTML;

        // Insert the header content into the container
        document.getElementById('header1').innerHTML = headerContent;
        document.getElementById('signup-modal').innerHTML = signUpModal;
        document.getElementById('signin-modal').innerHTML = signInModal;
    })
    .catch(error => console.error('Error fetching header:', error));

// Get the modal elements
const signUpModal = document.getElementById('signup-modal');
const signInModal = document.getElementById('signin-modal');

// Get the buttons that open the modals
const signUpBtn = document.querySelector('.sign-up');
const signInBtn = document.querySelector('.sign-in');

// Get the close buttons
const signUpCloseBtn = signUpModal.querySelector('.close');
const signInCloseBtn = signInModal.querySelector('.close');


function openModal(modal) {
    modal.style.display = 'block';
}

// Function to close the modal
function closeModal(modal) {
    modal.style.display = 'none';
}

// Event listener for the Sign Up button
signUpBtn.addEventListener('click', () => {
    console.log("Click")
    openModal(signUpModal)});
// Event listener for the Sign In button
signInBtn.addEventListener('click', () => openModal(signInModal));

// Event listeners for the close buttons
signUpCloseBtn.addEventListener('click', () => closeModal(signUpModal));
signInCloseBtn.addEventListener('click', () => closeModal(signInModal));

// Get the "Sign Up" button
const signUpButton = signUpModal.querySelector('.button');

function validateForm() {
    const nameInput = signUpModal.querySelector('input[name="name"]');
    const usernameInput = signUpModal.querySelector('input[name="username"]');
    const passwordInput = signUpModal.querySelector('input[name="password"]');
    const confirmPasswordInput = signUpModal.querySelector('input[name="confirm-password"]');

    if (!nameInput.value) {
        alert('Please fill out the Name field.');
        return false;
    }

    if (!usernameInput.value) {
        alert('Please fill out the Username field.');
        return false;
    }

    if (!passwordInput.value) {
        alert('Please fill out the Password field.');
        return false;
    }

    if (!confirmPasswordInput.value) {
        alert('Please fill out the Confirm Password field.');
        return false;
    }

    if (passwordInput.value !== confirmPasswordInput.value) {
        alert('Password and Confirm Password do not match.');
        return false;
    }

    return true;
}

// Event listener for the "Sign Up" button
signUpButton.addEventListener('click', function (event) {
    event.preventDefault(); // Prevent the form from submitting

    if (validateForm()) {
        // Perform sign up logic or submit the form here
        console.log('Form submitted successfully!');
    }
});

// Get the "Sign Up" hyperlink in the sign-in modal
const signUpLink = signInModal.querySelector('.sign-up-link');

// Function to handle the click event for the "Sign Up" hyperlink
function handleSignUpLinkClick(event) {
    event.preventDefault();
    closeModal(signInModal);
    openModal(signUpModal);
}

// Event listener for the "Sign Up" hyperlink
signUpLink.addEventListener('click', handleSignUpLinkClick);
